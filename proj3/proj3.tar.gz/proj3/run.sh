#!/bin/bash
python3 mining.py integrated_data_final.csv 0.2 0.9